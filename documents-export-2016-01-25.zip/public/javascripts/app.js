angular.module('tarefas',[])

.controller('mainController', function($scope, $http){

  $scope.formData = {};
  $scope.todoData = {};

  $http.get('/tarefas')
        .success(function(data) {
            $scope.todoData = data;
            console.log(data);
        })
        .error(function(error) {
            console.log('Error: ' + error);
        });

/*  $scope.deleteTodo = function(todoID) {
        $http.delete('/tareafas/' + todoID)
            .success(function(data) {
                $scope.todoData = data;
                console.log(data);
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });
    };*/

});
