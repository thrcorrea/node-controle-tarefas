﻿create or replace function f_insere_periodo_tarefa(integer)
returns boolean as 
$BODY$

declare

	v_id_tarefa alias for $1;

begin

	if ()


end;

$BODY$
language 'plpgsql';


alter table tarefas
	add encerrada boolean default false;